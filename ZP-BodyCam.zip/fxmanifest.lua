fx_version 'cerulean'
game 'gta5'

author 'Zippy OFC'
description 'Bodycam script'
version '1.0.0'


-- Please dont try to steal my work, BUT feel free to buy or obtain more free work from me at https://zippy-productions.com


client_script 'client.lua'

files {
    'sounds/beep.ogg',
    'images/bodycam.png',
    'index.html'
}

ui_page 'index.html'
